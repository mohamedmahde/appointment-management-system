@extends('layouts.dashboard')

@section('content')
@if(auth()->user()->user_type == 'مدير')
<div class="container mx-auto px-4 py-5">
    <h2 class="text-xl font-bold mb-4">جدول المواعيد</h2>
    <div class="mb-4 flex flex-row-reverse">
        <input type="text" id="searchInput" placeholder="🔍 ابحث عن موعد أو اسم..." class="form-input w-1/2 rounded border px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" style="direction:rtl">
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const input = document.getElementById('searchInput');
        input.addEventListener('input', function() {
            const filter = input.value.trim().toLowerCase();
            const rows = document.querySelectorAll('table tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    });
    </script>
    <table class="min-w-full bg-white">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b text-right">العنوان</th>
<th class="py-2 px-4 border-b text-right">اسم الشخص</th>
                <th class="py-2 px-4 border-b text-right">الطالب</th>
                <th class="py-2 px-4 border-b text-right">المدير</th>
                <th class="py-2 px-4 border-b text-right">وقت الموعد</th>
                <th class="py-2 px-4 border-b text-right">الحالة</th>
                <th class="py-2 px-4 border-b text-right">تاريخ الإنشاء</th>
                <th class="py-2 px-4 border-b text-right">إجراء</th>
            </tr>
        </thead>
        <tbody>
            @php
    $requests = \App\Models\Request::with(['sender', 'receiver'])
        ->where('type', 'مقابلة')
        ->orderByDesc('created_at')
        ->get();
@endphp
@forelse($requests as $request)
<tr>
    <td class="py-2 px-4 border-b">{{ $request->title ?? '-' }}</td>
<td class="py-2 px-4 border-b">{{ $request->interviewee_name ?? '-' }}</td>
    <td class="py-2 px-4 border-b">{{ $request->sender->name ?? '-' }}</td>
    <td class="py-2 px-4 border-b">{{ $request->receiver->name ?? '-' }}</td>
    <td class="py-2 px-4 border-b">{{ $request->scheduled_time ? $request->scheduled_time : '-' }}</td>
    <td class="py-2 px-4 border-b">{{ $request->status ?? '-' }}</td>
    <td class="py-2 px-4 border-b">{{ $request->created_at->format('Y-m-d H:i') }}</td>
    <td class="py-2 px-4 border-b">
        <style>
.icon-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.35rem 0.7rem;
    border-radius: 0.375rem;
    font-weight: 500;
    border: none;
    cursor: pointer;
    font-size: 0.95em;
    transition: background 0.2s;
    margin-left: 0.25em;
    margin-right: 0.25em;
}
.icon-view { background: #2563eb; color: #fff; }
.icon-view:hover { background: #1d4ed8; }
.icon-action { background: #6366f1; color: #fff; }
.icon-action:hover { background: #4338ca; }
.icon-btn .icon { font-size: 1.1em; margin-left: 0.5em; }
[dir="rtl"] .icon-btn .icon { margin-left: 0; margin-right: 0.5em; }
</style>
<a href="{{ route('requests.show', $request->id) }}" class="icon-btn icon-view" title="عرض الطلب"><span class="icon">👁️</span>عرض</a>

        @if(auth()->user()->user_type == 'مدير')
        <form action="{{ route('requests.update', $request->id) }}" method="POST" class="mt-2 space-y-1" style="min-width:180px" enctype="multipart/form-data" onsubmit="return validateSchedule{{ $request->id }}(this)">
    @csrf
    @method('PUT')
    <select name="action" class="form-input w-full mb-1" id="actionSelect{{ $request->id }}" data-id="{{ $request->id }}">
        <option value="accept">قبول المقابلة فورًا</option>
        <option value="schedule">تحديد وقت لاحق</option>
        <option value="reject">رفض المقابلة</option>
    </select>
    <div id="scheduleField{{ $request->id }}" style="display:none">
        <input type="datetime-local" name="scheduled_time" class="form-input w-full mb-1" id="scheduledInput{{ $request->id }}" data-id="{{ $request->id }}">
    </div>

    <div id="rejectionReasonField{{ $request->id }}" style="display:none">
        <textarea name="rejection_reason" class="form-input w-full mb-1" placeholder="سبب الرفض..." id="rejectionInput{{ $request->id }}" data-id="{{ $request->id }}"></textarea>
    </div>
    <button type="submit" class="icon-btn icon-action" title="إرسال القرار"><span class="icon">📤</span>إرسال القرار</button>
</form>
        @endif
    </td>
</tr>
@empty
<tr>
    <td colspan="7" class="py-2 px-4 border-b text-center">لا توجد مواعيد</td>
</tr>
@endforelse
        </tbody>
    </table>
</div>
@include('appointments.index_js')
@else
<div class="container mx-auto px-4 py-5 text-center text-gray-500">
    جدول المواعيد متاح فقط للمدير.
</div>
@endif
@if(session('success'))
    <script>
        let msg = @json(session('success'));
        let status = '';
        @if(session('success').includes('قبول'))
            status = 'تم قبول المقابلة';
        @elseif(session('success').includes('رفض'))
            status = 'تم رفض المقابلة';
        @elseif(session('success').includes('تأجيل') || session('success').includes('مؤجل'))
            status = 'تم تأجيل المقابلة';
        @endif
        if(status) {
            let utter = new SpeechSynthesisUtterance(status);
            utter.lang = 'ar-SA';
            window.speechSynthesis.speak(utter);
        }
    </script>
@endif
@endsection
