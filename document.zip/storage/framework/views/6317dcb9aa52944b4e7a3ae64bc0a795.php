<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->user_type == 'مدير'): ?>
<div class="container mx-auto px-4 py-5">
    <h2 class="text-xl font-bold mb-4">جدول المواعيد</h2>
    <div class="mb-4 flex flex-row-reverse">
        <input type="text" id="searchInput" placeholder="🔍 ابحث عن موعد أو اسم..." class="form-input w-1/2 rounded border px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" style="direction:rtl">
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const input = document.getElementById('searchInput');
        input.addEventListener('input', function() {
            const filter = input.value.trim().toLowerCase();
            const rows = document.querySelectorAll('table tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    });
    </script>
    <table class="min-w-full bg-white">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b text-right">العنوان</th>
<th class="py-2 px-4 border-b text-right">اسم الشخص</th>
                <th class="py-2 px-4 border-b text-right">الطالب</th>
                <th class="py-2 px-4 border-b text-right">المدير</th>
                <th class="py-2 px-4 border-b text-right">وقت الموعد</th>
                <th class="py-2 px-4 border-b text-right">الحالة</th>
                <th class="py-2 px-4 border-b text-right">تاريخ الإنشاء</th>
                <th class="py-2 px-4 border-b text-right">إجراء</th>
            </tr>
        </thead>
        <tbody>
            <?php
    $requests = \App\Models\Request::with(['sender', 'receiver'])
        ->where('type', 'مقابلة')
        ->orderByDesc('created_at')
        ->get();
?>
<?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td class="py-2 px-4 border-b"><?php echo e($request->title ?? '-'); ?></td>
<td class="py-2 px-4 border-b"><?php echo e($request->interviewee_name ?? '-'); ?></td>
    <td class="py-2 px-4 border-b"><?php echo e($request->sender->name ?? '-'); ?></td>
    <td class="py-2 px-4 border-b"><?php echo e($request->receiver->name ?? '-'); ?></td>
    <td class="py-2 px-4 border-b"><?php echo e($request->scheduled_time ? $request->scheduled_time : '-'); ?></td>
    <td class="py-2 px-4 border-b"><?php echo e($request->status ?? '-'); ?></td>
    <td class="py-2 px-4 border-b"><?php echo e($request->created_at->format('Y-m-d H:i')); ?></td>
    <td class="py-2 px-4 border-b">
        <style>
.icon-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.35rem 0.7rem;
    border-radius: 0.375rem;
    font-weight: 500;
    border: none;
    cursor: pointer;
    font-size: 0.95em;
    transition: background 0.2s;
    margin-left: 0.25em;
    margin-right: 0.25em;
}
.icon-view { background: #2563eb; color: #fff; }
.icon-view:hover { background: #1d4ed8; }
.icon-action { background: #6366f1; color: #fff; }
.icon-action:hover { background: #4338ca; }
.icon-btn .icon { font-size: 1.1em; margin-left: 0.5em; }
[dir="rtl"] .icon-btn .icon { margin-left: 0; margin-right: 0.5em; }
</style>
<a href="<?php echo e(route('requests.show', $request->id)); ?>" class="icon-btn icon-view" title="عرض الطلب"><span class="icon">👁️</span>عرض</a>

        <?php if(auth()->user()->user_type == 'مدير'): ?>
        <form action="<?php echo e(route('requests.update', $request->id)); ?>" method="POST" class="mt-2 space-y-1" style="min-width:180px" enctype="multipart/form-data" onsubmit="return validateSchedule<?php echo e($request->id); ?>(this)">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <select name="action" class="form-input w-full mb-1" id="actionSelect<?php echo e($request->id); ?>" data-id="<?php echo e($request->id); ?>">
        <option value="accept">قبول المقابلة فورًا</option>
        <option value="schedule">تحديد وقت لاحق</option>
        <option value="reject">رفض المقابلة</option>
    </select>
    <div id="scheduleField<?php echo e($request->id); ?>" style="display:none">
        <input type="datetime-local" name="scheduled_time" class="form-input w-full mb-1" id="scheduledInput<?php echo e($request->id); ?>" data-id="<?php echo e($request->id); ?>">
    </div>

    <div id="rejectionReasonField<?php echo e($request->id); ?>" style="display:none">
        <textarea name="rejection_reason" class="form-input w-full mb-1" placeholder="سبب الرفض..." id="rejectionInput<?php echo e($request->id); ?>" data-id="<?php echo e($request->id); ?>"></textarea>
    </div>
    <button type="submit" class="icon-btn icon-action" title="إرسال القرار"><span class="icon">📤</span>إرسال القرار</button>
</form>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="7" class="py-2 px-4 border-b text-center">لا توجد مواعيد</td>
</tr>
<?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo $__env->make('appointments.index_js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php else: ?>
<div class="container mx-auto px-4 py-5 text-center text-gray-500">
    جدول المواعيد متاح فقط للمدير.
</div>
<?php endif; ?>
<?php if(session('success')): ?>
    <script>
        let msg = <?php echo json_encode(session('success'), 15, 512) ?>;
        let status = '';
        <?php if(session('success').includes('قبول')): ?>
            status = 'تم قبول المقابلة';
        <?php elseif(session('success').includes('رفض')): ?>
            status = 'تم رفض المقابلة';
        <?php elseif(session('success').includes('تأجيل') || session('success').includes('مؤجل')): ?>
            status = 'تم تأجيل المقابلة';
        <?php endif; ?>
        if(status) {
            let utter = new SpeechSynthesisUtterance(status);
            utter.lang = 'ar-SA';
            window.speechSynthesis.speak(utter);
        }
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ai\document\document\resources\views/appointments/index.blade.php ENDPATH**/ ?>