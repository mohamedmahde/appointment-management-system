<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-5">
    <div class="mb-6">
        <h1 class="text-2xl font-bold">لوحة التحكم</h1>
        <p class="text-gray-600">مرحباً بك في النظام الإداري</p>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-lg shadow p-5">
            <h3 class="text-lg font-bold mb-2">المستخدمون</h3>
            <p class="text-3xl font-bold"><?php echo e(\App\Models\User::count()); ?></p>
            <a href="<?php echo e(route('users.index')); ?>" class="text-indigo-600 hover:underline block mt-3">عرض الكل</a>
        </div>
        
        <div class="bg-white rounded-lg shadow p-5">
            <h3 class="text-lg font-bold mb-2">المستندات</h3>
            <p class="text-3xl font-bold"><?php echo e(\App\Models\Document::count()); ?></p>
            <a href="<?php echo e(route('documents.index')); ?>" class="text-indigo-600 hover:underline block mt-3">عرض الكل</a>
        </div>
        
        <div class="bg-white rounded-lg shadow p-5">
            <h3 class="text-lg font-bold mb-2">الطلبات</h3>
            <p class="text-3xl font-bold"><?php echo e(\App\Models\Request::count()); ?></p>
            <a href="<?php echo e(route('requests.index')); ?>" class="text-indigo-600 hover:underline block mt-3">عرض الكل</a>
        </div>
        
        <div class="bg-white rounded-lg shadow p-5">
            <h3 class="text-lg font-bold mb-2">المواعيد</h3>
            <p class="text-3xl font-bold"><?php echo e(\App\Models\Appointment::count()); ?></p>
            <a href="<?php echo e(route('appointments.index')); ?>" class="text-indigo-600 hover:underline block mt-3">عرض الكل</a>
        </div>
    </div>
    <!-- جدول مختصر للمواعيد -->
    <div class="bg-white rounded-lg shadow p-5 mb-8">
        <h3 class="text-lg font-bold mb-4">جدول المواعيد القادمة</h3>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b text-right">العنوان</th>
                        <th class="py-2 px-4 border-b text-right">الطالب</th>
                        <th class="py-2 px-4 border-b text-right">المدير</th>
                        <th class="py-2 px-4 border-b text-right">وقت الموعد</th>
                        <th class="py-2 px-4 border-b text-right">الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = \App\Models\Appointment::whereNotNull('appointment_time')->orderBy('appointment_time','asc')->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="py-2 px-4 border-b"><?php echo e($appointment->title ?? '-'); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($appointment->requester->name ?? '-'); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($appointment->manager->name ?? '-'); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($appointment->appointment_time ? $appointment->appointment_time->format('Y-m-d H:i') : '-'); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($appointment->status ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="py-2 px-4 border-b text-center">لا توجد مواعيد قادمة</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a href="<?php echo e(route('appointments.index')); ?>" class="text-indigo-600 hover:underline block mt-3">عرض كل المواعيد</a>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg shadow p-5">
            <h3 class="text-lg font-bold mb-4">آخر الطلبات</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 border-b text-right">العنوان</th>
                            <th class="py-2 px-4 border-b text-right">المرسل</th>
                            <th class="py-2 px-4 border-b text-right">التاريخ</th>
                            <th class="py-2 px-4 border-b text-right">الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Request::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="py-2 px-4 border-b"><?php echo e($request->title); ?></td>
                            <td class="py-2 px-4 border-b"><?php echo e($request->sender->name); ?></td>
                            <td class="py-2 px-4 border-b"><?php echo e($request->created_at->format('Y-m-d')); ?></td>
                            <td class="py-2 px-4 border-b"><?php echo e($request->status); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="py-2 px-4 border-b text-center">لا توجد طلبات</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-5">
            <h3 class="text-lg font-bold mb-4">المواعيد القادمة</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 border-b text-right">العنوان</th>
                            <th class="py-2 px-4 border-b text-right">الطالب</th>
                            <th class="py-2 px-4 border-b text-right">التاريخ</th>
                            <th class="py-2 px-4 border-b text-right">الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Appointment::where('appointment_time', '>=', now())->orderBy('appointment_time')->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="py-2 px-4 border-b"><?php echo e($appointment->title); ?></td>
                            <td class="py-2 px-4 border-b"><?php echo e($appointment->requester->name); ?></td>
                            <td class="py-2 px-4 border-b"><?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('Y-m-d H:i')); ?></td>
                            <td class="py-2 px-4 border-b"><?php echo e($appointment->status); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="py-2 px-4 border-b text-center">لا توجد مواعيد قادمة</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<audio id="notifySound" src="/sounds/notify.mp3" preload="auto"></audio>
<script>
// مثال: تشغيل الصوت إذا كان هناك طلب جديد أو تحديث قرار
<?php if(session('success')): ?>
    document.getElementById('notifySound').play();
<?php endif; ?>
// يمكن توسيع المنطق باستخدام WebSocket أو polling لمتابعة التغييرات الحية
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ai\document\document\resources\views/dashboard.blade.php ENDPATH**/ ?>