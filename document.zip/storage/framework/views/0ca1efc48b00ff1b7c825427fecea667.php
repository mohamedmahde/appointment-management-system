<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-5">
    <h2 class="text-xl font-bold mb-4">تعديل الطلب</h2>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-4">
            <ul class="list-disc list-inside text-red-600">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('requests.update', $request->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-4">
            <label for="title" class="block mb-2 font-semibold">عنوان الطلب</label>
            <input type="text" id="title" name="title" class="form-input w-full" required value="<?php echo e(old('title', $request->title)); ?>">
        </div>
        <div class="mb-4">
            <label for="interviewee_name" class="block mb-2 font-semibold">اسم شخص المقابلة</label>
            <input type="text" id="interviewee_name" name="interviewee_name" class="form-input w-full" required value="<?php echo e(old('interviewee_name', $request->interviewee_name)); ?>">
        </div>
        <div class="mb-4">
            <label for="description" class="block mb-2 font-semibold">سبب المقابلة</label>
            <textarea id="description" name="description" class="form-input w-full" rows="3" required><?php echo e(old('description', $request->description)); ?></textarea>
        </div>
        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">حفظ التعديلات</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ai\document\document\resources\views/requests/edit.blade.php ENDPATH**/ ?>