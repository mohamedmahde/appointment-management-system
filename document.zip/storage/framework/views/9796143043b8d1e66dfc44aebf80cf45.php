<?php $__env->startSection('content'); ?>
<style>
.btn-details {
    display: inline-block;
    padding: 0.5rem 1.2rem;
    background: #2563eb;
    color: #fff !important;
    border-radius: 0.375rem;
    font-weight: 600;
    font-size: 1em;
    text-align: center;
    transition: background 0.2s, box-shadow 0.2s;
    box-shadow: 0 2px 8px rgba(37,99,235,0.08);
    border: none;
    outline: none;
    text-decoration: none !important;
}
.btn-details:hover, .btn-details:focus {
    background: #1d4ed8;
    color: #fff !important;
    box-shadow: 0 4px 16px rgba(37,99,235,0.13);
    text-decoration: none !important;
}
</style>
<div class="container mx-auto px-4 py-5">
    <h2 class="text-xl font-bold mb-4">الطلبات المقبولة</h2>
    <table class="min-w-full bg-white">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b text-right">العنوان</th>
                <th class="py-2 px-4 border-b text-right">اسم الشخص</th>
                <th class="py-2 px-4 border-b">الوصف</th>
                <th class="py-2 px-4 border-b">تاريخ الإنشاء</th>
                <th class="py-2 px-4 border-b">الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="py-2 px-4 border-b"><?php echo e($request->title); ?></td>
<td class="py-2 px-4 border-b"><?php echo e($request->interviewee_name ?? '-'); ?></td>
                <td class="py-2 px-4 border-b"><?php echo e($request->description); ?></td>
                <td class="py-2 px-4 border-b"><?php echo e($request->created_at->format('Y-m-d H:i')); ?></td>
                <td class="py-2 px-4 border-b">
                    <a href="<?php echo e(route('requests.show', $request->id)); ?>" class="btn-details">عرض التفاصيل</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="py-2 px-4 border-b text-center">لا توجد طلبات مقبولة</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ai\document\document\resources\views/requests/accepted.blade.php ENDPATH**/ ?>