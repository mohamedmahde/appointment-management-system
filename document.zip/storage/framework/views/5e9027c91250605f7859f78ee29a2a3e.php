<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - مكتب المدير</title>
    <!-- روابط ملفات القالب المنقولة إلى public/assets -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/jsvectormap/css/jsvectormap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/simplebar/simplebar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/@iconscout/unicons/css/line.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/@mdi/font/css/materialdesignicons.min.css')); ?>">
    <?php $__currentLoopData = scandir(base_path('assets/css')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($file != '.' && $file != '..' && Str::endsWith($file, '.css') && $file != 'dark-mode-fix.css'): ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/css/'.$file)); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- أي ملفات CSS إضافية -->
    <?php echo $__env->yieldContent('styles'); ?>

    
    <?php $__currentLoopData = scandir(base_path('assets/images')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($file != '.' && $file != '..' && (Str::endsWith($file, '.png') || Str::endsWith($file, '.jpg') || Str::endsWith($file, '.jpeg') || Str::endsWith($file, '.gif') || Str::endsWith($file, '.svg'))): ?>
            
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</head>
<body class="font-nunito text-base text-black">
    <div class="page-wrapper toggled">
        <!-- الشريط الجانبي -->
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- محتوى الصفحة -->
        <main class="page-content bg-gray-50">
            <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="container-fluid relative px-3">
                <div class="layout-specing">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </main>
    </div>
    <!-- ملفات الجافاسكريبت -->
    <script src="<?php echo e(asset('assets/libs/jsvectormap/js/jsvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apexchart.init.js')); ?>"></script>
    <?php $__currentLoopData = scandir(base_path('assets/js')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($file != '.' && $file != '..' && $file != 'dark-mode.js'): ?>
            <script src="<?php echo e(asset('assets/js/'.$file)); ?>"></script>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\ai\document\document\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>